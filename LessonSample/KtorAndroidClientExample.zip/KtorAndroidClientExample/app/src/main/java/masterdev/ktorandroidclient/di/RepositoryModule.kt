package masterdev.ktorandroidclient.di

import masterdev.ktorandroidclient.data.repository.RemoteRepositoryImpl
import masterdev.ktorandroidclient.network.ApiService
import masterdev.ktorandroidclient.network.RetrofitServices
import org.koin.dsl.module

val repositoryModule = module {
    single { provideRemoteRepository(get(), get()) }
}

fun provideRemoteRepository(apiService: ApiService, retrofitServices: RetrofitServices): RemoteRepositoryImpl {
    return RemoteRepositoryImpl(apiService, retrofitServices)
}
