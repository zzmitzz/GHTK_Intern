package masterdev.ktorandroidclient.di

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.gson.GsonBuilder
import masterdev.ktorandroidclient.Constant.CACHE_CONTROL
import masterdev.ktorandroidclient.Constant.TIME_CACHE_OFFLINE
import masterdev.ktorandroidclient.Constant.TIME_CACHE_ONLINE
import masterdev.ktorandroidclient.network.RetrofitServices
import okhttp3.Cache
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.core.scope.Scope
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

private const val CONNECT_TIMEOUT = 15L
private const val WRITE_TIMEOUT = 15L
private const val READ_TIMEOUT = 15L

val retrofitModule =
    module {
        single(createdAtStart = false) { get<Retrofit>().create(RetrofitServices::class.java) }
        single { Cache(androidApplication().cacheDir, 10L * 1024 * 1024) }
        single { GsonBuilder().create() }
        single { retrofitHttpClient(androidContext()) }
        single { retrofitBuilder() }
    }

private fun Scope.retrofitBuilder(): Retrofit =
    Retrofit
        .Builder()
        .baseUrl("https://www.thecocktaildb.com")
        .addConverterFactory(GsonConverterFactory.create(get()))
//         .addCallAdapterFactory(RxJava2CallAdapterFactory.create()) rx --> Coroutines
        .client(get())
        .build()

private fun isNetworkAvailable(context: Context): Boolean {
    val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val nw = connectivityManager.activeNetwork ?: return false
    val actNw = connectivityManager.getNetworkCapabilities(nw) ?: return false
    return when {
        actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
        actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
        // for other device how are able to connect with Ethernet
        actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
        // for check internet over Bluetooth
        actNw.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> true
        else -> false
    }
}

private fun Scope.retrofitHttpClient(context: Context): OkHttpClient =
    OkHttpClient
        .Builder()
        .apply {
            cache(get())
            connectTimeout(CONNECT_TIMEOUT, TimeUnit.SECONDS)
            writeTimeout(WRITE_TIMEOUT, TimeUnit.SECONDS)
            readTimeout(READ_TIMEOUT, TimeUnit.SECONDS)
            retryOnConnectionFailure(true)
            addInterceptor(
                Interceptor { chain ->
                    var request: Request = chain.request()
                    request =
                        if (isNetworkAvailable(context)) {
                            request
                                .newBuilder()
                                .header(CACHE_CONTROL, TIME_CACHE_ONLINE)
                                .header("Accept", "application/json")
                                .build()
                        } else {
                            request
                                .newBuilder()
                                .header(CACHE_CONTROL, TIME_CACHE_OFFLINE)
                                .header("Accept", "application/json")
                                .build()
                        }
                    chain.proceed(request)
                },
            )
            addInterceptor(
                HttpLoggingInterceptor().apply {
                    level = HttpLoggingInterceptor.Level.BODY
                },
            )
        }.build()
