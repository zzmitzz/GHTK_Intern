package masterdev.ktorandroidclient

object Constant {
    const val CACHE_SIZE: Long = (10 * 1024 * 1024).toLong()
    const val READ_TIMEOUT: Int = 5000
    const val WRITE_TIMEOUT: Int = 5000
    const val CONNECT_TIMEOUT: Int = 5000
    const val CACHE_CONTROL: String = "Cache-Control"
    const val TIME_CACHE_ONLINE: String = "public, max-age = 60" // 1 minute
    const val TIME_CACHE_OFFLINE: String = "public, only-if-cached, max-stale = 86400" // 1 day
}
