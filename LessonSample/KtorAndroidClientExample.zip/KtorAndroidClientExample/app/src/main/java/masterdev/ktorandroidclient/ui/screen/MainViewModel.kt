package masterdev.ktorandroidclient.ui.screen

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import masterdev.ktorandroidclient.data.model.Drink
import masterdev.ktorandroidclient.data.repository.RemoteRepositoryImpl

class MainViewModel(
    private val remoteRepositoryImpl: RemoteRepositoryImpl,
) : ViewModel() {
    private val _items: MutableStateFlow<List<Drink>> = MutableStateFlow(emptyList())
    val items: StateFlow<List<Drink>> = _items

    private val ktorMode: Boolean = false

    suspend fun loadItems() {
        viewModelScope.launch {
            val result =
                if (ktorMode) {
                    remoteRepositoryImpl.getDrinksWithKtor()
                } else {
                    remoteRepositoryImpl.getDrinksWithRetrofit()
                }

            result.fold(
                onSuccess = { drinks ->
                    _items.update { drinks }
                },
                onFailure = {
                    // something went wrong
                },
            )
        }
    }
}
