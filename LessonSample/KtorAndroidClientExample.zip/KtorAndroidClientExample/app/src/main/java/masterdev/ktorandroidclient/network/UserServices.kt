package masterdev.ktorandroidclient.network

import masterdev.ktorandroidclient.data.model.DrinksResponse
import retrofit2.http.GET
import retrofit2.http.Headers

interface RetrofitServices {
    @Headers("Accept: application/json")
    @GET("/api/json/v1/1/filter.php?c=Ordinary_Drink")
    suspend fun getDrinks(): DrinksResponse
}