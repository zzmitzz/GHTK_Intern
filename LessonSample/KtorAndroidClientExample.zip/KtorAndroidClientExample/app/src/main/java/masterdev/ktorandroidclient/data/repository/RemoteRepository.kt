package masterdev.ktorandroidclient.data.repository

import masterdev.ktorandroidclient.data.model.Drink

interface RemoteRepository {
    suspend fun getDrinksWithKtor(): Result<List<Drink>>
    suspend fun getDrinksWithRetrofit(): Result<List<Drink>>
}
