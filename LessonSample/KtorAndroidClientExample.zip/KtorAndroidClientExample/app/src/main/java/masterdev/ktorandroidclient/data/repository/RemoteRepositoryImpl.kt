package masterdev.ktorandroidclient.data.repository

import io.ktor.client.call.body
import masterdev.ktorandroidclient.data.model.Drink
import masterdev.ktorandroidclient.data.model.DrinksResponse
import masterdev.ktorandroidclient.network.ApiService
import masterdev.ktorandroidclient.network.RetrofitServices

class RemoteRepositoryImpl(
    private val apiService: ApiService,
    private val retrofitServices: RetrofitServices,
) : RemoteRepository {
    override suspend fun getDrinksWithKtor(): Result<List<Drink>> =
        runCatching {
            apiService.getDrinks().body<DrinksResponse>().drinks
        }

    override suspend fun getDrinksWithRetrofit(): Result<List<Drink>> =
        runCatching {
            retrofitServices.getDrinks().drinks
        }
}
